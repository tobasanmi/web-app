<?php
//define('SENDGRID_API_KEY', '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');
define('SENDGRID_API_KEY', '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');
