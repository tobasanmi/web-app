<?php

// $dbServername ="localhost";
// $dbUsername ="root";
// $dbPassword ="";
// $dbName ="kbase";
 
// $conn = mysqli_connect($dbServername, $dbUsername, $dbPassword, $dbName);





define("DBHOST", "localhost");
define("DBUSER", "daydonec_max");
define("DBPASS", "qYDaBWX*vzhk");
define("DBNAME", "daydonec_main");

$conn = $cxn = mysqli_connect(DBHOST, DBUSER, DBPASS, DBNAME);